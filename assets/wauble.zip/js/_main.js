(function($) {
  $(window).ready(function() {
    console.log('Wauble Wordpress Starter Theme');
  })
})(jQuery);
