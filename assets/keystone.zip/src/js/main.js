// This code will be transpiled from ES6 and output in the header.

import { bIsNodeClippedOrOffscreen , CheckIfPointIsOffScreen } from './modules/MobileMenu';

let Keystone = {};

Keystone.bIsNodeClippedOrOffscreen = bIsNodeClippedOrOffscreen;
Keystone.CheckIfPointIsOffScreen = CheckIfPointIsOffScreen; 

var something = 'hello'; 

console.log( something );

export {Keystone}