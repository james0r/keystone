<?php
/**
* HOME BOXES STYLE 3 MODULE TEMPLATE
*/

$instance = $template_args['instance'];

$script_dependencies = [

];

$style_dependencies = [

];

apply_filters('render_dynamic_scripts', $script_dependencies);
apply_filters('render_dynamic_css', $style_dependencies);

?>
<div class="home-boxes-style-3-module-container">
  <div class="home-boxes-style-3-module-container-inner">
  </div>
</div>