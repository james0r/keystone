<?php
/**
* HOME BOXES STYLE 1 MODULE TEMPLATE
*/

$instance = $template_args['instance'];

$script_dependencies = [];

$style_dependencies = [];

Keystone()->renderModuleAssets($script_dependencies, $style_dependencies);
?>
<div class="home-boxes-style-1-module-container">
  <div class="home-boxes-style-1-module-container-inner">

  </div>
</div>