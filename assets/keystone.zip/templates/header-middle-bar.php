<div id="header-middle-bar" class="header-middle-bar">
  <div class="header-middle-bar-inner">
    
  </div>
</div>
