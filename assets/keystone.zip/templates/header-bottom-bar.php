<div id="header-bottom-bar" class="header-bottom-bar">

</div>