(function($) {
  $(window).ready(function() {
    console.log('Keystone Theme ©️ https://www.jamesauble.com');
  })
})(jQuery);
