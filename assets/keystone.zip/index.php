<?php

/**
 * THIS FILE SERVES AS THE DEFAULT TEMPLATE FOR PAGES
 */

get_header();
?>

<?php keystone_render_template('module-loop'); ?>

<?php

get_footer();

