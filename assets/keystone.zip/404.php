<section id="four-oh-four" class="four-oh-four">
  404
</section>
