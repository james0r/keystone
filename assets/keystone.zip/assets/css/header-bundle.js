/*---   function bIsNodeClippedOrOffscreen returns true if a node
        is offscreen (without scrolling).
        Requires jQuery.
*/




function test() {
  console.log( 'test it' );
}

// This code will be transpiled from ES6 and output in the header.

test();
