<?php wp_footer(); ?>

<!-- End wrapper div -->
</div>
<?php keystone_render_template('appointment-modal') ?>
</body>
</html>
